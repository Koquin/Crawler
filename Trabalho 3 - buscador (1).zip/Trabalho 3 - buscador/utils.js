import { question } from 'readline-sync';

function get_number(msg) {
    const entrada = question(msg);
    const numero = Number(entrada);

    if (isNaN(numero)) {
        console.error('Entrada inválida! Digite um número.');
        return get_number(msg);
    }

    return numero;
}

export function get_number_inrange(msg, min, max) {
    const numero = get_number(msg);

    if (numero < min || numero > max) {
        console.error(`Valor inválido! Digite um número entre ${min} e ${max}.`);
        return get_number_inrange(msg, min, max);
    }

    return numero;
}
