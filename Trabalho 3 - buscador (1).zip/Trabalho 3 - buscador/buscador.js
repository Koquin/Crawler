import axios from 'axios';
import { JSDOM } from 'jsdom';
import url from 'url';
import readline from 'readline';
import { get_number_inrange } from '../Trabalho 3 - buscador/utils.js';

const paginasVisitadas = [];
const conteudosBaixados = {};
const grafoDeLinks = {};

async function baixarPagina(link) {
    try {
        const response = await axios.get(link);
        return response.data;
    } catch (error) {
        console.error(`Erro ao baixar a página: ${link}`, error.message);
        return null;
    }
}

function extrairLinks(html, baseUrl) {
    const dom = new JSDOM(html);
    const document = dom.window.document;
    const links = Array.from(document.querySelectorAll('a'))
        .map(a => a.href)
        .filter(href => href)
        .map(href => {
            if (href.startsWith('http') || href.startsWith('https')) {
                return href;
            }
            return url.resolve(baseUrl, href);
        });
    return links;
}

async function crawler(link) {
    if (paginasVisitadas.includes(link)) return;

    const html = await baixarPagina(link);
    if (!html) return;

    paginasVisitadas.push(link);
    conteudosBaixados[link] = html;

    const linksEncontrados = extrairLinks(html, link);
    grafoDeLinks[link] = linksEncontrados;

    for (const novoLink of linksEncontrados) {
        await crawler(novoLink);
    }
}

function removerAcentos(str) {
    return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/ç/g, "c").replace(/Ç/g, "C");
}

function calcularPontuacao(term, paginas) {
    const pontuacoes = {};
    const termoNormalizado = removerAcentos(term.toLowerCase());

    for (const pagina of paginas) {
        const htmlOriginal = conteudosBaixados[pagina];
        const htmlNormalizado = removerAcentos(htmlOriginal.toLowerCase());

        const pontosTermo = (htmlNormalizado.match(new RegExp(termoNormalizado, 'g')) || []).length * 5;

        let pontosAutoridade = 0;
        for (const [outraPagina, links] of Object.entries(grafoDeLinks)) {
            if (outraPagina !== pagina && links.includes(pagina)) {
                pontosAutoridade += 10;
            }
        }

        const autoreferencia = grafoDeLinks[pagina]?.includes(pagina) ? -15 : 0;
        const total = pontosTermo + pontosAutoridade + autoreferencia;

        pontuacoes[pagina] = {
            pontosTermo,
            pontosAutoridade,
            penalidade: autoreferencia,
            total
        };
    }

    return pontuacoes;
}


function desempatar(p1, p2, pontuacoes) {
    const a = pontuacoes[p1];
    const b = pontuacoes[p2];

    if (a.pontosAutoridade !== b.pontosAutoridade) {
        return b.pontosAutoridade - a.pontosAutoridade;
    }

    if (a.pontosTermo !== b.pontosTermo) {
        return b.pontosTermo - a.pontosTermo;
    }

    if (a.penalidade !== b.penalidade) {
        return a.penalidade - b.penalidade;
    }

    return p1.localeCompare(p2);
}

function exibirResultados(pontuacoes, modoDetalhado = false) {
    const pontuacoesFiltradas = Object.fromEntries(
        Object.entries(pontuacoes).filter(([_, dados]) => dados.pontosTermo > 0)
    );

    const paginasOrdenadas = Object.keys(pontuacoesFiltradas).sort((p1, p2) => {
        const diffTotal = pontuacoesFiltradas[p2].total - pontuacoesFiltradas[p1].total;
        if (diffTotal !== 0) return diffTotal;
        return desempatar(p1, p2, pontuacoesFiltradas);
    });

    if (paginasOrdenadas.length === 0) {
        console.log('\nNenhuma página contém o termo buscado.\n');
        return;
    }

    console.log('\n=== RESULTADO DO BUSCADOR ===\n');


    if (modoDetalhado) {
        const headers = [
            'Posição'.padEnd(8),
            'Página'.padEnd(45),
            'Ocorrências (+5)'.padEnd(20),
            'Links Recebidos (+10)'.padEnd(24),
            'Autorreferência (-15)'.padEnd(24),
            'Total'.padEnd(6)
        ];

        const separator = headers.map(h => '-'.repeat(h.length)).join(' | ');

        console.log('| ' + headers.join(' | ') + ' |');
        console.log('|-' + separator + '-|');

        let posicao = 1;
        for (const pagina of paginasOrdenadas) {
            const { total, pontosTermo, pontosAutoridade, penalidade } = pontuacoes[pagina];
            const ocorrencias = pontosTermo / 5;
            const linha = [
                String(posicao).padEnd(8),
                pagina.padEnd(45),
                `${ocorrencias}×5 = ${pontosTermo}`.padEnd(20),
                String(pontosAutoridade).padEnd(24),
                String(penalidade).padEnd(24),
                String(total).padEnd(6)
            ];
            console.log('| ' + linha.join(' | ') + ' |');
            posicao++;
        }
    } else {
        let pos = 1;
        for (const pagina of paginasOrdenadas) {
            const { total } = pontuacoes[pagina];
            console.log(`${pos}. ${pagina} — ${total} pontos`);
            pos++;
        }
    }

    console.log('');
}

async function main() {
    while (true) {
        const rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        });

        await new Promise((resolve) => {
            rl.question('\nDIGITE O TERMO QUE VOCÊ QUER BUSCAR (adicione "detalhado" para ver mais informações): ', async (entrada) => {
                const palavras = entrada.trim().split(/\s+/).filter(p => p.length > 0);

                if (palavras.length === 0 || (palavras.length === 1 && palavras[0].toLowerCase() === "detalhado")) {
                    console.error('\nEntrada inválida! Você deve digitar pelo menos um termo de busca.');
                    rl.close();
                    resolve();
                    return;
                }

                const modoDetalhado = palavras[palavras.length - 1].toLowerCase() === "detalhado";
                const termo = modoDetalhado ? palavras.slice(0, -1).join(" ") : palavras.join(" ");

                await crawler("https://koquin.github.io/blade_runner.html");
                const pontuacoes = calcularPontuacao(termo, paginasVisitadas);
                console.clear();
                console.log(`\nTermo buscado: "${termo}"\n`);
                exibirResultados(pontuacoes, modoDetalhado);
                rl.close();
                resolve();
            });
        });

        paginasVisitadas.length = 0;
        Object.keys(conteudosBaixados).forEach(k => delete conteudosBaixados[k]);
        Object.keys(grafoDeLinks).forEach(k => delete grafoDeLinks[k]);

        const continuar = get_number_inrange('\nDigite 0 para sair ou 1 para buscar outro termo: ', 0, 1);
        if (continuar === 0) {
            console.log("Encerrando o buscador. Até mais!");
            break;
        }
        console.clear();
    }
}

main();
